﻿(function () {
    'use strict';
   
    angular
       .module('siteServiceModule', ['ngResource'])
       .factory('Site', Site);

    Site.$inject = ['$resource'];

    function Site($resource) {
        var urlBase = '/api/sites';
        var factory = {};

        factory.getSites() = function () {
            var resource = $resource(urlBase);//, { Id: "@Id" }, { "update": { method: "PUT" } });
            return resource.query();
        }

        factory.addSite() = function () {
            return $resource(urlBase, { Id: "@Id" }, { "update": { method: "PUT" } });
        }
        return factory;
    }

})();