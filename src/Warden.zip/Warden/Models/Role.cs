﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Warden.Models
{
    /// <summary>
    /// 
    /// </summary>
    public enum Role
    {
        Employee,
        ChefWarden,
        DeputyWarden,
        FloorWarden,
        Warden
    }
}
