﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Warden.Models
{
    public class Site
    {
        public string Name { get; set; }

        /// <summary>
        /// TODO: change to an object
        /// </summary>
        public string Address { get; set; }
    }
}
