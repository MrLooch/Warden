﻿(function () {
    'use strict';

    angular.module('wardenapp').controller('SiteQueryController', SiteQueryController);

    SiteQueryController.$inject = ['Site2'];

    function SiteQueryController(Site2) {
        var vm = this;
        vm.sites = {}; //Site.query();

        vm.test = "Looch";

        vm.getData = function () {
            return "Hello Function";
        };
    }
})();
