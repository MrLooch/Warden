﻿(function () {
    'use strict';
   
    angular
        .module('wardenApp', ['ngResource'])
        .service('SiteQueryService', SiteQueryService);

    SiteQueryService.$inject = ['$resource'];

    function SiteQueryService($resource) {

        //this.query = function ()
        //{
        //    return $resource('/api/sites/');
        //}
    }

})();